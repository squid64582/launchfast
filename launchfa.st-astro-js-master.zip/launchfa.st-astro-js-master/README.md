<p align="center">
  <a href="https://www.launchfa.st">
    <img alt="LaunchFa.st" src="https://www.launchfa.st/seo.png">
    <h1 align="center">LaunchFa.st Astro JavaScript Boilerplate</h1>
  </a>
</p>

<p align="center">
Launch your apps in hours with this Astro JavaScript boilerplate.
</p>

## Demo

[https://youtu.be/NgyDG8qxz18](https://youtu.be/NgyDG8qxz18)

## Documentation

[https://www.launchfa.st/documentation](https://www.launchfa.st/documentation)

## Author

- Rishi Raj Jain ([@rishi*raj_jain*](https://twitter.com/rishi_raj_jain_))
